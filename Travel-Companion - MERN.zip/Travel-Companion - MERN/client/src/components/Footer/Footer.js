import React from "react";
import "./Footer.scss";

const Footer = () => {
  return <div className="footer">&copy; Panda 💖</div>;
};

export default Footer;
